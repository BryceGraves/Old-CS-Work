#pragma once

struct dot* dot_struct(float x, float y, float r);
void dot_draw(struct dot*);
void dot_move_right(struct dot*);
void dot_move_down(struct dot*);
void dot_grow(struct dot*);
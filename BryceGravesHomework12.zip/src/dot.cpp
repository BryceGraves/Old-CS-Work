#include "dot.h"
#include "ofMain.h"

struct dot {
	float x;
	float y;
	float r;
};

struct dot *dot_struct(float x, float y, float r) {
	struct dot *thisDot = (struct dot*)malloc(sizeof(struct dot));
	thisDot->x = x;
	thisDot->y = y;
	thisDot->r = r;
	return thisDot;
}

void dot_move_right(struct dot* dot) {
	dot->x += 0.25;
}


void dot_move_down(struct dot* dot) {
	dot->y += 0.25;
}

void dot_grow(struct dot* dot) {
	if (dot->r > 0){
		dot->r -= 0.05;
	}
	else { dot->r = 0; }
	
}

void dot_draw(struct dot* dot) {
	
	ofDrawCircle(dot->x, dot->y, dot->r);
	ofSetColor(100, 50, 20);
}

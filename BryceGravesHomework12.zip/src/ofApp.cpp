#include "ofApp.h"
#include "dot.h"
#include "block.h"




void ofApp::setup() {
	ofSetBackgroundColor(255, 0, 0);
	ofSetBoxResolution(60);
	whiteDot = dot_struct(100, 250, 50);
	redBlock = block_struct(50, 125, 25, 25);
}


void ofApp::update() {
	dot_move_right(whiteDot);
	dot_move_down(whiteDot);
	dot_grow(whiteDot);
	block_move_down(redBlock);
	block_move_right(redBlock);
	block_grow(redBlock);
}


void ofApp::draw() {
	dot_draw(whiteDot);
	block_draw(redBlock);
}

//--------------------------------------------------------------
void ofApp::keyPressed(int key) {

}

//--------------------------------------------------------------
void ofApp::keyReleased(int key) {

}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y) {

}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button) {

}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button) {

}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button) {

}

//--------------------------------------------------------------
void ofApp::mouseEntered(int x, int y) {

}

//--------------------------------------------------------------
void ofApp::mouseExited(int x, int y) {

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h) {

}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg) {

}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo) {

}
#include "block.h"
#include "ofMain.h"

struct block {
	float x;
	float y;
	float r;
	float h;
};

struct block *block_struct(float x, float y, float r, float h) {
	struct block *thisBlock = (struct block*)malloc(sizeof(struct block));
	thisBlock->x = x;
	thisBlock->y = y;
	thisBlock->r = r;
	thisBlock->h = h;
	return thisBlock;
}

void block_draw(struct block* block) {
	ofDrawRectangle(block->x, block->y, block->r, block->h);
}

void block_move_down(struct block* block) {
	block->x += 0.10;
}

void block_move_right(struct block* block) {
	block->y += 0.10;
}

void block_grow(struct block* block) {
	block->r += 0.10;
	block->h += 0.10;
}

#pragma once

struct block* block_struct(float x, float y, float r, float h);
void block_draw(struct block*);
void block_move_right(struct block*);
void block_move_down(struct block*);
void block_grow(struct block*);
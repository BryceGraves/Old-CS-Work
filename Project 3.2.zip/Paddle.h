#pragma once
#include "ofMain.h"

class Paddle {

	public:
		float x;
		float y;
		float v;
		int width;
		int height;
		ofColor color;
		Paddle();
		Paddle(float x, float y, float v, int width, int height, ofColor color);
		void draw();
		void moveUp();
		void moveDown();
		void move();
		void slow();
		
};
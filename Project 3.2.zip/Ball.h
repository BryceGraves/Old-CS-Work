#pragma once
#include "ofMain.h"

class Ball {

public:
	float x;
	float y;
	float xVelocity;
	float yVelocity;
	int size;
	ofColor color;
	Ball();
	Ball(float x, float y, float xVelocity, float yVelocity, int size, ofColor color);
	void draw();
	void move();
};
#include "ofApp.h"
#include "Paddle.h"
#include "Ball.h"

const int PADDLES = 2;

//--------------------------------------------------------------
void ofApp::setup() {
	ofSetBackgroundColor(0);
	phil = new Paddle(60, (ofGetHeight() / 2), 0, 20, 60, ofColor(0, 255, 0));
	stan = new Paddle((ofGetWidth() - 80), (ofGetHeight() / 2), 0, 20, 60, ofColor(0, 255, 0));
	bob = new Ball((ofGetWidth() / 2), (ofGetHeight() / 2), ofRandom(-1, 0), ofRandom(-1, 1), 10, ofColor(0, 255, 0));
}

//--------------------------------------------------------------
void ofApp::update() {
	phil->move();
	phil->slow();
	bob->move();

	if (((bob->x + bob->size) == (phil->x = phil->x)) && ((bob->y) < (phil->y + phil->height) || (bob->y) > (phil->y - phil->height))) {
		bob->xVelocity *= -1;
	}
}

//--------------------------------------------------------------
void ofApp::draw() {
	phil->draw();
	stan->draw();
	bob->draw();
}

//--------------------------------------------------------------
void ofApp::keyPressed(int key) {
	if (key == OF_KEY_UP) {
		phil->moveUp();
	}
	
	if (key == OF_KEY_DOWN) {
		phil->moveDown();
	}
}

//--------------------------------------------------------------
void ofApp::keyReleased(int key) {

}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y ) {

}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button) {

}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button) {

}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button) {

}

//--------------------------------------------------------------
void ofApp::mouseEntered(int x, int y) {

}

//--------------------------------------------------------------
void ofApp::mouseExited(int x, int y) {

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h) {

}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg) {

}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo) { 

}

#include "ofApp.h"

using namespace std;

const int START_SCREEN = 0;
const int GAME_SCREEN = 1;
const int GAME_OVER_SCREEN = 2;

int gameState = START_SCREEN;

void ofApp::setup() {
	
	//Read from file and push into vector lines
	vector<string> lines;
	ofBuffer buffer = ofBufferFromFile("data.txt");
	for (auto line : buffer.getLines()) {
		lines.push_back(line);
	}

	//Takes vector lines and fills it with strings called row
	for (int i = 0; i < lines.size(); ++i) {
		string row = lines[i];
		cout << "ROW " << i + 1 << endl;

		//Takes each string and prints each char per string
		for (int j = 0; j < row.size(); ++j) {
			cout << "Block: " << row[j] << endl;
			
			double blockWidth = (ofGetWidth() / row.size());
			double blockHeight = ((ofGetHeight() / 2) / lines.size());

			//For each char, construct a specific blockWidth
			if (row[j] == 'A') {
				blocks.push_back(new Block(blockWidth * j, 50 + (blockHeight * i), blockWidth, blockHeight, 1, ofColor(0, 255, 255)));
			} else if (row[j] == 'B') {
				blocks.push_back(new Block(blockWidth * j, 50 + (blockHeight * i), blockWidth, blockHeight, 1, ofColor(255, 0, 0)));
			} else if (row[j] == 'C') {
				blocks.push_back(new Block(blockWidth * j, 50 + (blockHeight * i), blockWidth, blockHeight, 1, ofColor(0, 255, 0)));
			} else if (row[j] == 'D') {
				blocks.push_back(new Block(blockWidth * j, 50 + (blockHeight * i), blockWidth, blockHeight, 1, ofColor(0, 0, 255)));
			} else if (row[j] == 'E') {
				blocks.push_back(new Block(blockWidth * j, 50 + (blockHeight * i), blockWidth, blockHeight, 1, ofColor(255, 255, 0)));
			} else if (row[j] == 'F') {
				blocks.push_back(new Block(blockWidth * j, 50 + (blockHeight * i), blockWidth, blockHeight, 1, ofColor(255, 0, 255)));
			}
		}
	}

	
	//Set background color and framerate
	ofSetBackgroundColor(0);
	ofSetFrameRate(60);

	//Load fonts, titles, and sounds
	myFont.load("Font.ttf", 10);
	titleFont.load("Font.ttf", 50);
	Title.load("Title.png");
	paddleSound.load("paddleSound.wav");
	
	//constructs paddle and ball; Also sets their starting velocity
	playerPaddle = new Paddle(((ofGetWidth() / 2) - 30), ofGetHeight() - 60, 0, 60, 20, ofColor(0, 255, 0));
	ball = new Ball(10, ofColor(0, 255, 0), 0, 3);
	ball->velocity.set(1, 5);
	ball->location.set((ofGetWidth() / 2), (ofGetHeight() / 2));
}


void ofApp::update() {
	//Check to see if gamestate is on update screen. TODO: Make update screen for the three other levels
	if (gameState == GAME_SCREEN) {
		updateGameScreen();
	}
}


void ofApp::draw() {
	//Checks gamestate and draws the correct screen
	if (gameState == START_SCREEN) {
		drawStartScreen();
	}
	else if (gameState == GAME_SCREEN) {
		drawGameScreen();
	}
	else if (gameState == GAME_OVER_SCREEN) {
		drawGameOverScreen();
	}
}


void ofApp::drawStartScreen() {
	//Set the color to white; draw the title and the strings for level names
	ofSetColor(255, 255, 255);
	titleFont.drawString("1. Easy", 50, (ofGetWindowHeight() / 2) + 20);
	titleFont.drawString("2. Kind of Hard", 50, (ofGetWindowHeight() / 2) + 100);
	titleFont.drawString("3. Hard", 50, (ofGetWindowHeight() / 2) + 180);
	titleFont.drawString("4. Please Don't Do It", 50, (ofGetWindowHeight() / 2) + 260);
	Title.draw(0, 150, ofGetWindowWidth(), 200);

}


void ofApp::drawGameScreen() {
	//Draw FPS and Framenumber labels
	ofSetColor(255, 255, 255);
	std::string str_fps = "FPS: ";
	str_fps += ofToString(ofGetFrameRate());
	std::string str_frameNum = "Frame #: ";
	str_frameNum += ofToString(ofGetFrameNum());
	std::string str_score = "Score: ";
	str_score += ofToString(ball->score);
	std::string str_highscore = "High Score: ";

	
	//Draw framerate, framenumber, and score; with color
	ofSetColor(255, 255, 255);
	myFont.drawString(str_fps, 10, 40);
	myFont.drawString(str_frameNum, 10, 20);
	myFont.drawString(str_score, (ofGetWidth() / 2) - 50, 20);

	//Draws circles to represent lives in the top right corner
	ofSetColor(0, 255, 0);
	if (ball->lives == 3) {
		ofDrawCircle((ofGetWindowWidth() - ((ball->size * 1) + 1)), ball->size, ball->size);
		ofDrawCircle((ofGetWindowWidth() - ((ball->size * 3) + 1)), ball->size, ball->size);
		ofDrawCircle((ofGetWindowWidth() - ((ball->size * 5) + 1)), ball->size, ball->size);
	}
	else if (ball->lives == 2) {
		ofDrawCircle((ofGetWindowWidth() - ((ball->size * 1) + 1)), ball->size, ball->size);
		ofDrawCircle((ofGetWindowWidth() - ((ball->size * 3) + 1)), ball->size, ball->size);
	}
	else if (ball->lives == 1) {
		ofDrawCircle((ofGetWindowWidth() - ((ball->size * 1) + 1)), ball->size, ball->size);
	}
	else {
		gameState++;
	}

	//Draw each block in the block vector
	for (int i = 0; i < blocks.size(); ++i) {
		blocks[i]->draw();
	}
	
	//Draws the paddle and ball
	playerPaddle->draw();
	ball->draw();
	ofSetColor(0, 255, 0);

}


void ofApp::drawGameOverScreen() {

}


void ofApp::updateGameScreen() {
	//Moves the paddle and ball
	playerPaddle->move();
	ball->move();

	//Ball bounces on paddle, checks the x bounds and the y bounds before bounce
	if ((ball->location.y + ball->size) >= (playerPaddle->y)) {
		if ((ball->location.x - ball->size) <= (playerPaddle->x + (playerPaddle->width))) {
			if ((ball->location.x + ball->size) >= (playerPaddle->x)) {
				//Angled ball bounce, maps the width of the paddle to a -2 to 2 x velocity
				float Bounce = ofMap(ball->location.x, playerPaddle->x, playerPaddle->x + (playerPaddle->width), -2, 2);
				ball->velocity.x = Bounce;
				ball->velocity.y *= -1;
				++ball->score;
				paddleSound.play();
			}
		}
	}
}


void ofApp::keyPressed(int key) {
	//Dev mode, manually change gamestate. TODO: change to click travel/button travel
	if (key == OF_KEY_SHIFT) {
		gameState = (gameState + 1) % 3;
	}
}


void ofApp::keyReleased(int key) {

}


void ofApp::mouseMoved(int x, int y ) {

}


void ofApp::mouseDragged(int x, int y, int button) {

}


void ofApp::mousePressed(int x, int y, int button) {

}


void ofApp::mouseReleased(int x, int y, int button) {

}


void ofApp::mouseEntered(int x, int y) {

}


void ofApp::mouseExited(int x, int y) {

}


void ofApp::windowResized(int w, int h) {

}


void ofApp::gotMessage(ofMessage msg) {

}


void ofApp::dragEvent(ofDragInfo dragInfo) {

}

#include "ofMain.h"
#include "Paddle.h"



Paddle::Paddle() {
	x = ofGetWindowWidth();
	y = ofGetWindowHeight();
	width = 5;
	height = 5;
	color = ofColor();
}


Paddle::Paddle(float x, float y, float v, int width, int height, ofColor color) {
	this->x = x;
	this->y = y;
	this->v = v;
	this->width = width;
	this->height = height;
	this->color = color;
}


void Paddle::draw() {
	ofSetColor(color);
	ofDrawRectangle(x, y, width, height);
	ofSetBoxResolution(60);
}


void Paddle::move() {
	//Bounds for paddle at the edge of the screen
	if (x <= 0) {
		x = 0;
	}
	else if (x >= ofGetWindowWidth() - width) {
		x = ofGetWindowWidth() - width;
	}

	//Mouse tracking for paddle
	if (ofGetMouseX() - (width / 2) < (x - 3)) {
		x -= 3;
	} else if (ofGetMouseX() - (width / 2) > (x + 3)) {
		x += 3;
	}
}



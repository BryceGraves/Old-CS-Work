#include "Game.h"
#include "ofMain.h"

void Game::construct() {
	Paddle *playerPaddle = new Paddle(((ofGetWidth() / 2) - 30), ofGetHeight() - 60, 0, 60, 20, ofColor(0, 255, 0));
}

void Game::draw() {
	Paddle draw(*playerPaddle);
}

void Game::move() {
	playerPaddle->move();
}
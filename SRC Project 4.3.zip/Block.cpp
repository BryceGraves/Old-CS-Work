#include "Block.h"
#include "ofMain.h"


Block::Block() {

}

Block::Block(double x, double y, double width, double height, int score, ofColor color) {
	this->x = x;
	this->y = y;
	this->width = width;
	this->height = height;
	this->score = score;
	this->color = color;
}

void Block::draw() {
	ofSetColor(color);
	ofDrawRectangle(x, y, width, height);
	ofSetBoxResolution(60);
}

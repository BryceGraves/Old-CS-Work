#pragma once
#include "ofMain.h"
#include "Paddle.h"

class Game {
	Paddle *playerPaddle;
	void construct();
	void draw();
	void move();
};
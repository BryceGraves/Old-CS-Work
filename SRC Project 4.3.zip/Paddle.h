#pragma once
#include "ofMain.h"

class Paddle {

	public:
		float x;
		float y;
		float v;
		int width;
		int height;
		ofColor color;
		Paddle();
		Paddle(float x, float y, float v, int width, int height, ofColor color);
		void draw();
		void move();
};
class Unicorn < Beast

  def suffix
    "Wheee!"
  end

end

class Troll < Beast

  def suffix
    "UNGH!"
  end

end

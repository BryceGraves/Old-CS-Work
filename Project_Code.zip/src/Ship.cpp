#include "Ship.h"
#include "ofMain.h"


//Ship data type declared
struct ship {
	float x;
	float xVelocity;
	float wiggle;
	float y;
	float yVelocity;
	int w;
	int h;
	ofImage spaceShip;
};

//Ship memory allocation
struct ship *ship_struct(float x, float xVelocity, float wiggle, float y, float yVelocity, int w, int h) {
	struct ship *thisship = (struct ship*)malloc(sizeof(struct ship));
	thisship->x = x;
	thisship->xVelocity = 0;
	thisship->wiggle = wiggle;
	thisship->y = y;
	thisship->yVelocity = 0;
	thisship->w = w;
	thisship->h = h;
	return thisship;
}

//ship draw
void ship_draw(struct ship* ship, ofImage spaceShip) {
	ofSetColor(255, 255, 255);
	spaceShip.draw(ship->x, ship->y, ship->w, ship->h);
}

void ship_move_right(struct ship* ship) {
	ship->xVelocity += 0.1;
}

void ship_move_left(struct ship* ship) {
	ship->xVelocity -= 0.1;
}

void ship_move_up(struct ship* ship) {
	ship->yVelocity -= 0.1;
}

void ship_move_down(struct ship* ship) {
	ship->yVelocity += 0.1;
}

void move_ship(struct ship* ship) {
	
	ship->x += ship->xVelocity;
	ship->y += ship->yVelocity;
	ship->wiggle += 0.005;
	ship->y += (sin(ship->wiggle)) / 40;
	
	if (ship->x <= 0) {
		ship->x = 0;
		ship->xVelocity *= -0.2;
	} else if (ship->x >= ofGetWindowWidth() - ship->w) {
		ship->x = ofGetWindowWidth() - ship->w;
		ship->xVelocity *= -0.2;
	}

	if (ship->y <= 0) {
		ship->y = 0;
		ship->yVelocity *= -0.2;
	} else if (ship->y >= ofGetWindowHeight() - ship->w) {
		ship->y = ofGetWindowHeight() - ship->w;
		ship->yVelocity *= -0.2;
	}

	

}

float get_ship_xposition(struct ship* ship) {
	return ship->x;
}

float get_ship_yposition(struct ship* ship) {
	return ship->y;
}


#pragma once
#include "ofMain.h"

struct ship* ship_struct(float x, float xVelocity, float wiggle, float y, float yVelocity, int w, int h);
void ship_draw(struct ship*, ofImage spaceShip);
void move_ship(struct ship*);
void ship_move_right(struct ship*);
void ship_move_left(struct ship*);
void ship_move_up(struct ship*);
void ship_move_down(struct ship*);
float get_ship_xposition(struct ship*);
float get_ship_yposition(struct ship*);
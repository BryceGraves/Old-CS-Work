#pragma once

struct star* star_construct();
void star_move(struct star* star);
void star_draw(struct star* star);
#include "ofApp.h"
#include "Ship.h"
#include "Star.h"
#include "Bullet.h"

void ofApp::setup() {
	
	//Set Background color
	ofSetBackgroundColor(0, 0, 0);
	
	//Fill background with stars
	for (int i = 0; i < 20; ++i) {
		stars[i] = star_construct();
	}
	
	//Creates a ship
	ship = ship_struct((ofGetWindowWidth()/2), 0, 0, (ofGetWindowHeight() - 100), 0, 100, 100);
	
	//Loads files: ship sprite, Fonts, and background music.
	spaceShip.load("ship.png");
	myFont.load("font.ttf", 10);
	soundPlayer.loadSound("beat.wav");
	soundPlayer.setLoop(true);
	soundPlayer.play();

}

void ofApp::update() {
	
	//Updates ships position and movement
	move_ship(ship);

	//Updates star positions an movement
	for (int i = 0; i < 20; ++i) {
		star_move(stars[i]);
	}

	//Updates bullet movement, and deconstructs bullets when offscreen
	for (int i = 0; i < 10; ++i) {
		if (bullets[i] != NULL) {
			bullet_move(bullets[i]);
			if (bullet_offscreen(bullets[i]) == TRUE) {
				free(bullets[i]);
				bullets[i] = NULL;
			}
		}
	}
}

void ofApp::draw() {
	
	//Draw the star objects in the background
	for (int i = 0; i < 20; ++i) {
		star_draw(stars[i]);
	}

	//Loop that draws all bullet that exist within the window
	for (int i = 0; i < 10; ++i) {
		if (bullets[i] != NULL) {
				bullet_draw(bullets[i]);
		}
	}
	
	//Drawing the ship with image overlay
	ship_draw(ship, spaceShip);

	//Draw FPS and Framenumber labels
	ofSetColor(255, 255, 255);
	std::string str_fps = "FPS: ";
	str_fps += ofToString(ofGetFrameRate());
	ofSetColor(255, 255, 255);
	std::string str_frameNum = "Frame #: ";
	str_frameNum += ofToString(ofGetFrameNum());

	//Draw framerate, framenumber, and score, with color
	ofSetColor(255, 255, 255);
	myFont.drawString("score:", (ofGetWidth() / 2) - 50, 30);
	myFont.drawString(str_fps, 10, 40);
	myFont.drawString(str_frameNum, 10, 20);

}

void ofApp::keyPressed(int key) {
	//Keyboard controls for ship
	if (key == OF_KEY_RIGHT) {
		ship_move_right(ship);
	}
	if (key == OF_KEY_LEFT) {
		ship_move_left(ship);
	}

	if (key == OF_KEY_UP) {
		ship_move_up(ship);
	}
	if (key == OF_KEY_DOWN) {
		ship_move_down(ship);
	}

	//Fire bullets (Adds bullet construct to array, if statement checks for empty array slot.
	if (key == OF_KEY_LEFT_SHIFT) {
		for (int i = 0; i < 10; ++i) {
			if (bullets[i] == NULL) {
				bullets[i] = bullet_construct(get_ship_xposition(ship) + 50, get_ship_yposition(ship) + 10, 1);
				break;
			}
		}
	}
}

void ofApp::keyReleased(int key) {

}

void ofApp::mouseMoved(int x, int y ) {

}

void ofApp::mouseDragged(int x, int y, int button) {

}

void ofApp::mousePressed(int x, int y, int button) {

}

void ofApp::mouseReleased(int x, int y, int button) {

}

void ofApp::mouseEntered(int x, int y) {

}

void ofApp::mouseExited(int x, int y) {

}

void ofApp::windowResized(int w, int h) {

}

void ofApp::gotMessage(ofMessage msg) {

}

void ofApp::dragEvent(ofDragInfo dragInfo) { 

}
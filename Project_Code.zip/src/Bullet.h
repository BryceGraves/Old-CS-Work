#pragma once

struct bullet* bullet_construct(float x, float y, float v);
void bullet_move(struct bullet* bullet);
void bullet_draw(struct bullet* bullet);
float get_bullet_yposition(struct bullet* bullet);
bool bullet_offscreen(struct bullet* bullet);
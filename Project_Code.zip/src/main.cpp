#include "ofMain.h"
#include "ofApp.h"

//Bryce Graves
//Final Project: 

//This program consists of a ship that is moveable using the arrow keys. You can fire bullets using the left shift key.

int main( ) {
	ofSetupOpenGL(1366,768,OF_FULLSCREEN);
	ofRunApp(new ofApp());

}

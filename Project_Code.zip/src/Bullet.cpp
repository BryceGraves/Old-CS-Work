#include "Bullet.h"
#include "ofApp.h"
#include "ofMain.h"

struct bullet {
	float x;
	float y;
	float v;
	ofColor c;
};

struct bullet* bullet_construct(float x, float y, float v) {
	struct bullet *thisbullet = (struct bullet*)malloc(sizeof(struct bullet));
	thisbullet->x = x;
	thisbullet->y = y;
	thisbullet->v = v;
	thisbullet->c = ofColor(255, 0, 0);

	return thisbullet;
}

void bullet_move(struct bullet* bullet) {
	bullet->y -= bullet->v;
}

void bullet_draw(struct bullet* bullet) {
	ofSetColor(bullet->c);
	ofSetLineWidth(3);
	ofDrawLine(bullet->x, bullet->y, bullet->x, bullet->y + 5);
}

float get_bullet_yposition(struct bullet* bullet) {
	return bullet->y;
}

bool bullet_offscreen(struct bullet* bullet) {
	if (bullet->y <= 0) {
		return TRUE;
	}
	else {
		return FALSE;
	}
}
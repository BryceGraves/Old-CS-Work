#include "ofMain.h"
#include "ofApp.h"

//Bryce Graves
//Homework 15: Project work

//I am almost glad I don't have a git repo of this because it was a struggle getting sine to work.

int main( ) {
	ofSetupOpenGL(1366,768,OF_FULLSCREEN);
	ofRunApp(new ofApp());

}

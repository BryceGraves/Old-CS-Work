#include "ofApp.h"
#include "Ship.h"
#include "backgroundSauce.h"

void ofApp::setup() {
	ofSetBackgroundColor(0, 0, 0);
	ship = ship_struct((ofGetWindowWidth()/2), 0, 0, (ofGetWindowHeight() - 200), 50, 50, 0, 0, 255);
}

void ofApp::update() {
	moveShip(ship);
	shipFloat(ship);
}

void ofApp::draw() {
	drawFpsAndScore();
	ship_draw(ship);
	
}

void ofApp::keyPressed(int key) {
	if (key == OF_KEY_RIGHT) {
		ship_move_right(ship);
	}
	if (key == OF_KEY_LEFT) {
		ship_move_left(ship);
	}
	
}

void ofApp::keyReleased(int key) {

}

void ofApp::mouseMoved(int x, int y ) {

}

void ofApp::mouseDragged(int x, int y, int button) {

}

void ofApp::mousePressed(int x, int y, int button) {

}

void ofApp::mouseReleased(int x, int y, int button) {

}

void ofApp::mouseEntered(int x, int y) {

}

void ofApp::mouseExited(int x, int y) {

}

void ofApp::windowResized(int w, int h) {

}

void ofApp::gotMessage(ofMessage msg) {

}

void ofApp::dragEvent(ofDragInfo dragInfo) { 

}
#pragma once

struct ship* ship_struct(float x, float velocity, float wiggle, float y, int w, int h, int r, int g, int b);
void ship_draw(struct ship*);
void moveShip(struct ship*);
void ship_move_right(struct ship*);
void ship_move_left(struct ship*);
void shipFloat(struct ship*);
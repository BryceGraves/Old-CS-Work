#include "Ship.h"
#include "ofMain.h"

struct ship {
	float x;
	float velocity;
	float wiggle;
	float y;
	int w;
	int h;
	int r;
	int g;
	int b;
};

struct ship *ship_struct(float x, float velocity, float wiggle, float y, int w, int h, int r, int g, int b) {
	struct ship *thisship = (struct ship*)malloc(sizeof(struct ship));
	thisship->x = x;
	thisship->velocity = 0;
	thisship->wiggle = wiggle;
	thisship->y = y;
	thisship->w = w;
	thisship->h = h;
	thisship->r = r;
	thisship->g = g;
	thisship->b = b;
	return thisship;
}

void ship_draw(struct ship* ship) {
	ofSetColor(ship->r, ship->g, ship->b);
	ofDrawRectangle(ship->x, ship->y, ship->w, ship->h);
}

void ship_move_right(struct ship* ship) {
	ship->velocity += 1;
}

void ship_move_left(struct ship* ship) {
	ship->velocity -= 1;
}

void moveShip(struct ship* ship) {
	ship->x += ship->velocity;
	if (ship->x <= 0) {
		ship->velocity *= -1;
	} else if (ship->x >= ofGetWindowWidth()-ship->w) {
		ship->velocity *= -1;
	}

	/*ship->y += ship->wiggle;
	if (ship->y >= ofGetWindowHeight()) {
		ship->wiggle *= -1;
	} else if (ship->y <= ofGetWindowHeight() - 150) {
		ship->wiggle *= -1;
	}*/
}

void shipFloat(struct ship* ship) {
	ship->wiggle += 0.02;
	ship->y += sin(ship->wiggle);
}
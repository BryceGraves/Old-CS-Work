#pragma once

void drawFpsAndScore();
#pragma once

#include "ofMain.h"

class Block {

public:
	float x;
	float y;
	int width;
	int height;
	int score;
	ofColor color;
	int BlockA(float x, float y, int width, int height, int score, ofColor color);
	int BlockB(float x, float y, int width, int height, int score, ofColor color);
	int BlockC(float x, float y, int width, int height, int score, ofColor color);
	int BlockD(float x, float y, int width, int height, int score, ofColor color);
	int BlockE(float x, float y, int width, int height, int score, ofColor color);
	int BlockF(float x, float y, int width, int height, int score, ofColor color);
	void draw();
};
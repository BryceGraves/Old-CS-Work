#include "ofApp.h"

using namespace std;

const int START_SCREEN = 0;
const int GAME_SCREEN = 1;
const int GAME_OVER_SCREEN = 2;

int gameState = START_SCREEN;

void ofApp::setup() {
	vector<string> lines;
	ofBuffer buffer = ofBufferFromFile("data.txt");
	for (auto line : buffer.getLines()) {
		lines.push_back(line);
	}

	for (int i = 0; i < lines.size(); ++i) {
		string row = lines[i];
		cout << "ROW " << i + 1 << endl;
		for (int j = 0; j < row.size(); ++j) {
			cout << "Block: " << row[j] << endl;
			//blocks.push_back( new block(code, ??? * i);
		}
	}


	ofSetBackgroundColor(0);
	myFont.load("Font.ttf", 10);
	paddleSound.load("paddleSound.wav");
	playerPaddle = new Paddle(((ofGetWidth() / 2) - 30), ofGetHeight() - 60, 0, 60, 20, ofColor(0, 255, 0));
	ball = new Ball(10, ofColor(0, 255, 0), 0, 3);
	ball->velocity.set(0.5, 1);
	ball->location.set((ofGetWidth() / 2), (ofGetHeight() / 2));
}


void ofApp::update() {
	if (gameState == GAME_SCREEN) {
		updateGameScreen();
	}
}


void ofApp::draw() {
	if (gameState == START_SCREEN) {
		drawStartScreen();
	}
	else if (gameState == GAME_SCREEN) {
		drawGameScreen();
	}
	else if (gameState == GAME_OVER_SCREEN) {
		drawGameOverScreen();
	}
}


void ofApp::drawStartScreen() {
	
}


void ofApp::drawGameScreen() {
	//Draw FPS and Framenumber labels
	ofSetColor(255, 255, 255);
	std::string str_fps = "FPS: ";
	str_fps += ofToString(ofGetFrameRate());
	std::string str_frameNum = "Frame #: ";
	str_frameNum += ofToString(ofGetFrameNum());
	std::string str_score = "Score: ";
	str_score += ofToString(ball->score);


	//Draw framerate, framenumber, and score; with color
	ofSetColor(255, 255, 255);
	myFont.drawString(str_fps, 10, 40);
	myFont.drawString(str_frameNum, 10, 20);
	myFont.drawString(str_score, (ofGetWidth() / 2) - 50, 20);

	ofSetColor(0, 255, 0);
	if (ball->lives == 3) {
		ofDrawCircle((ofGetWindowWidth() - ((ball->size * 1) + 1)), ball->size, ball->size);
		ofDrawCircle((ofGetWindowWidth() - ((ball->size * 3) + 1)), ball->size, ball->size);
		ofDrawCircle((ofGetWindowWidth() - ((ball->size * 5) + 1)), ball->size, ball->size);
	}
	else if (ball->lives == 2) {
		ofDrawCircle((ofGetWindowWidth() - ((ball->size * 1) + 1)), ball->size, ball->size);
		ofDrawCircle((ofGetWindowWidth() - ((ball->size * 3) + 1)), ball->size, ball->size);
	}
	else if (ball->lives == 1) {
		ofDrawCircle((ofGetWindowWidth() - ((ball->size * 1) + 1)), ball->size, ball->size);
	}
	else {
		gameState++;
	}

	playerPaddle->draw();
	ball->draw();
	ofSetColor(0, 255, 0);

}


void ofApp::drawGameOverScreen() {

}


void ofApp::updateGameScreen() {
	playerPaddle->move();
	ball->move();

	if ((ball->location.y + ball->size) >= (playerPaddle->y)) {
		if ((ball->location.x - ball->size) <= (playerPaddle->x + (playerPaddle->width))) {
			if ((ball->location.x + ball->size) >= (playerPaddle->x)) {
				//The stuff of nightmares
				float distLeft = ofDist(ball->location.x, ball->location.y + ball->size, playerPaddle->x, playerPaddle->y);
				float distRight = ofDist(ball->location.x, ball->location.y + ball->size, playerPaddle->x + playerPaddle->width, playerPaddle->y);
				distLeft /= playerPaddle->width;
				distRight /= playerPaddle->width;
				float varience = distLeft * distRight;
				varience -= 1;
				varience *= 1.25;

				if (ball->location.x > playerPaddle->x + (playerPaddle->width / 2)) {
					
					ball->velocity.x *= varience;
				}
				else {
					varience *= -1;
					ball->velocity.x *= varience;
				}
				
				ball->velocity.y *= -1;
				++ball->score;
				paddleSound.play();
			}
		}
	}
}


void ofApp::keyPressed(int key) {
	if (key == OF_KEY_SHIFT) {
		gameState = (gameState + 1) % 3;
	}
}


void ofApp::keyReleased(int key) {

}


void ofApp::mouseMoved(int x, int y ) {

}


void ofApp::mouseDragged(int x, int y, int button) {

}


void ofApp::mousePressed(int x, int y, int button) {

}


void ofApp::mouseReleased(int x, int y, int button) {

}


void ofApp::mouseEntered(int x, int y) {

}


void ofApp::mouseExited(int x, int y) {

}


void ofApp::windowResized(int w, int h) {

}


void ofApp::gotMessage(ofMessage msg) {

}


void ofApp::dragEvent(ofDragInfo dragInfo) {

}

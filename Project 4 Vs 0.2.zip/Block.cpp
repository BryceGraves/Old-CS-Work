#include "Block.h"
#include "ofMain.h"


int Block::BlockA(float x, float y, int width, int height, int score, ofColor color) {
	this->x = x;
	this->y = y;
	this->width = width;
	this->height = height;
	this->color = color;
	this->score = score;
}

int Block::BlockB(float x, float y, int width, int height, int score, ofColor color) {
	this->x = x;
	this->y = y;
	this->width = width;
	this->height = height;
	this->color = color;
	this->score = score;
}

int Block::BlockC(float x, float y, int width, int height, int score, ofColor color) {
	this->x = x;
	this->y = y;
	this->width = width;
	this->height = height;
	this->color = color;
	this->score = score;
}

int Block::BlockD(float x, float y, int width, int height, int score, ofColor color) {
	this->x = x;
	this->y = y;
	this->width = width;
	this->height = height;
	this->color = color;
	this->score = score;
}

int Block::BlockE(float x, float y, int width, int height, int score, ofColor color) {
	this->x = x;
	this->y = y;
	this->width = width;
	this->height = height;
	this->color = color;
	this->score = score;
}

int Block::BlockF(float x, float y, int width, int height, int score, ofColor color) {
	this->x = x;
	this->y = y;
	this->width = width;
	this->height = height;
	this->color = color;
	this->score = score;
}

void Block::draw() {
	ofSetColor(color);
	ofDrawRectangle(x, y, width, height);
	ofSetBoxResolution(60);
}

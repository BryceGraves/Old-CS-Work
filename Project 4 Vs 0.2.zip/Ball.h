#pragma once


class Ball {

public:
	ofVec2f location, velocity, acceleration;
	int size;
	ofColor color;
	int score;
	int lives;
	Ball();
	Ball(int size, ofColor color, int score, int lives);
	void draw();
	void move();

};
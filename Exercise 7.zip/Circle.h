#pragma once

void drawManyCircles(int x);
#include "ofApp.h"
#include "C:\Users\Bryce\Desktop\of_v0.9.7_vs_release\apps\myApps\BryceGravesHomework11\dot.h"




void ofApp::setup() {
	ofSetBackgroundColor(0, 0, 0);
	ofSetCircleResolution(60);
	whiteDot = dot_struct(100, 250, 50);
}


void ofApp::update() {
	dot_move_right(whiteDot);
	dot_move_down(whiteDot);
	//dot_grow(whiteDot);
}


void ofApp::draw() {
	dot_draw(whiteDot);
}

//--------------------------------------------------------------
void ofApp::keyPressed(int key){

}

//--------------------------------------------------------------
void ofApp::keyReleased(int key){

}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y ){

}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseEntered(int x, int y){

}

//--------------------------------------------------------------
void ofApp::mouseExited(int x, int y){

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){

}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){ 

}

#pragma once

struct dot* dot_struct(int x, int y, float r);
void dot_draw(struct dot*);
void dot_move_right(struct dot*);
void dot_move_down(struct dot*);
//void dot_grow(struct dot*);
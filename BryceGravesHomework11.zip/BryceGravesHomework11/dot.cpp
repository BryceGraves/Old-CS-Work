#include "dot.h"
#include "ofMain.h"

struct dot {
	int x;
	int y;
	float r;
	ofColor color;
};

struct dot *dot_struct(int x, int y, float r) {
	struct dot *thisDot = (struct dot*)malloc(sizeof(struct dot));
	thisDot->x = x;
	thisDot->y = y;
	thisDot->r = r;
	return thisDot;
}

void dot_move_right(struct dot* dot) {
	dot->x++;
}


void dot_move_down(struct dot* dot) {
	dot->y++;
}

/*void dot_grow(struct dot* dot) {
	*dot_struct--
}*/

void dot_draw(struct dot* dot) {
	ofDrawCircle(dot->x, dot->y, dot->r);
	ofColor green(10, 140, 240);
}

#pragma once
#include "ofMain.h"

class Paddle {

public:
	int x;
	int y;
	int size;
	ofColor color;
	Paddle();
	Paddle(int x, int y, int size, ofColor color);
	void move();
	void draw();
};
#include "Paddle.h"
#include "ofMain.h"


Paddle::Paddle() {
	x = ofGetWindowWidth();
	y = ofGetWindowHeight();
	size = 5;
	color = ofColor();
}

Paddle::Paddle(int x, int y, int size, ofColor color) {
	this->x = x;
	this->y = y;
	this->size = size;
	this->color = color;
}

void Paddle::draw() {
	ofSetColor(color);
	ofDrawRectangle(ofGetWindowWidth(), ofGetWindowHeight(), 10, 10);
}
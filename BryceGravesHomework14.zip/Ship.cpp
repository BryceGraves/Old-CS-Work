#include "Ship.h"
#include "ofMain.h"

struct block {
	float x;
	float y;
	float w;
	float h;
	int r;
	int g;
	int b;
};

struct block *block_struct(float x, float y, float w, float h, int r, int g, int b) {
	struct block *thisBlock = (struct block*)malloc(sizeof(struct block));
	thisBlock->x = x;
	thisBlock->y = y;
	thisBlock->w = w;
	thisBlock->h = h;
	thisBlock->r = r;
	thisBlock->g = g;
	thisBlock->b = b;
	return thisBlock;
}

void block_draw(struct block* block) {
	ofDrawRectangle(block->x, block->y, block->w, block->h);
	ofSetColor(block->r, block->g, block->b);
}

void block_move_right(struct block* block) {
	block->x += 5;
}

void block_move_left(struct block* block) {
	block->x -= 5;
}

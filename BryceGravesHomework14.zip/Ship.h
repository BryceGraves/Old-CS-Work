#pragma once

struct block* block_struct(float x, float y, float w, float h, int r, int g, int b);
void block_draw(struct block*);
void block_move_right(struct block*);
void block_move_left(struct block*);
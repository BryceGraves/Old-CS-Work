#include "ofApp.h"
#include "Ship.h"

void ofApp::setup() {
	ofSetBackgroundColor(0, 0, 0);
	//ofSetBoxResolution(60);
	//ofSetFrameRate(60);
	blueBlock = block_struct(ofGetWindowWidth()/2, ofGetWindowHeight() - 50, 50, 50, 0, 0, 255);
	whiteBlock = block_struct(ofGetWindowWidth()/2, ofGetWindowHeight() - 30, 20, 20, 255, 255, 255);

}

void ofApp::update() {
	
}

void ofApp::draw() {
	block_draw(blueBlock);
	block_draw(whiteBlock);
	
	std::string str_fps = "FPS: ";
	str_fps += ofToString(ofGetFrameRate());

	std::string str_frameNum = "Frame #: ";
	str_frameNum += ofToString(ofGetFrameNum());

	ofDrawBitmapString("score:", (ofGetWidth()/2) - 50, 30);
	ofDrawBitmapString(str_fps, 10, 20);
	ofDrawBitmapString(str_frameNum, 10, 10);
	
}

void ofApp::keyPressed(int key) {
	if (key == OF_KEY_RIGHT) {
		block_move_right(blueBlock);
	}
	if (key == OF_KEY_LEFT) {
		block_move_left(blueBlock);
	}
	if (key == OF_KEY_RIGHT) {
		block_move_right(whiteBlock);
	}
	if (key == OF_KEY_LEFT) {
		block_move_left(whiteBlock);
	}
}

void ofApp::keyReleased(int key) {

}

void ofApp::mouseMoved(int x, int y ) {

}

void ofApp::mouseDragged(int x, int y, int button) {

}

void ofApp::mousePressed(int x, int y, int button) {

}

void ofApp::mouseReleased(int x, int y, int button) {

}

void ofApp::mouseEntered(int x, int y) {

}

void ofApp::mouseExited(int x, int y) {

}

void ofApp::windowResized(int w, int h) {

}

void ofApp::gotMessage(ofMessage msg) {

}

void ofApp::dragEvent(ofDragInfo dragInfo) { 

}

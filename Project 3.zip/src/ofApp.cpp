#include "ofApp.h"
#include "Paddle.h"
#include "Ball.h"

using namespace std;

const int START_SCREEN = 0;
const int GAME_SCREEN = 1;
const int GAME_OVER_SCREEN = 2;


int gameState = START_SCREEN;
int HighScoreTemp;


void ofApp::setup() {
	ofSetBackgroundColor(0);
	myFont.load("Font.ttf", 10);
	highScoreFont.load("Font.ttf", 40);
	Title.load("Pongs_revenge.png");
	Title2.load("Pongs_revenge2.png");
	GameOver.load("GameOverScreen.png");
	HighScore.load("HighScore.png");
	PlayAgain.load("PlayAgain.png");
	paddleSound.load("paddleSound.wav");
	SeaGulls.load("SeaGulls.wav");
	SeaGulls.play();
	SeaGulls.setLoop(true);
	ofFile file("HighScores.txt", ofFile::ReadWrite);
	file.open("HighScores.txt");
	file >> HighScoreTemp;
	file.close();


	playerPaddle = new Paddle(60, (ofGetHeight() / 2), 0, 20, 60, ofColor(0, 255, 0));
	compPaddle = new Paddle((ofGetWidth() - 80), (ofGetHeight() / 2), 0, 20, 60, ofColor(0, 255, 0));
	ball = new Ball((ofGetWidth() / 2), (ofGetHeight() / 2), ofRandom(-2, 1), ofRandom(-0.5, 0.5), 10, ofColor(0, 255, 0), 0, 3);
	projectile = new Ball(-100, -100, 0, 0, 10, ofColor(0, 0, 255), 0, 0);
	
}


void ofApp::update() {
	if (gameState == GAME_SCREEN) {
		updateGameScreen();
	}
}


void ofApp::draw() {
	if (gameState == START_SCREEN) {
		drawStartScreen();
	}
	else if (gameState == GAME_SCREEN) {
		drawGameScreen();
	}
	else if (gameState == GAME_OVER_SCREEN) {
		drawGameOverScreen();
	}
}


void ofApp::drawStartScreen() {
	Title.draw(200, 150);
	Title2.draw(340, 400, 700, 100);
	std::string str_HighScore = "High Score: ";
	str_HighScore += ofToString(HighScoreTemp);
	highScoreFont.drawString(str_HighScore, 400, 650);
}


void ofApp::drawGameScreen() {
	//Draw FPS and Framenumber labels
	ofSetColor(255, 255, 255);
	std::string str_fps = "FPS: ";
	str_fps += ofToString(ofGetFrameRate());
	std::string str_frameNum = "Frame #: ";
	str_frameNum += ofToString(ofGetFrameNum());
	std::string str_score = "Score: ";
	str_score += ofToString(ball->score);
	std::string str_projectile = "Projectile: ";
	str_projectile += ofToString(projectile->score);


	//Draw framerate, framenumber, and score; with color
	ofSetColor(255, 255, 255);
	myFont.drawString(str_fps, 10, 40);
	myFont.drawString(str_frameNum, 10, 20);
	myFont.drawString(str_score, (ofGetWidth() / 2) - 50, 20);
	myFont.drawString(str_projectile, (ofGetWidth() / 2) + 200, 20);
	
	ofSetColor(0, 255, 0);
	if (ball->lives == 3) {
		ofDrawCircle((ofGetWindowWidth() - ((ball->size * 1) + 1)), ball->size, ball->size);
		ofDrawCircle((ofGetWindowWidth() - ((ball->size * 3) + 1)), ball->size, ball->size);
		ofDrawCircle((ofGetWindowWidth() - ((ball->size * 5) + 1)), ball->size, ball->size);
	} else if (ball->lives == 2) {
		ofDrawCircle((ofGetWindowWidth() - ((ball->size * 1) + 1)), ball->size, ball->size);
		ofDrawCircle((ofGetWindowWidth() - ((ball->size * 3) + 1)), ball->size, ball->size);
	} else if (ball->lives == 1) {
		ofDrawCircle((ofGetWindowWidth() - ((ball->size * 1) + 1)), ball->size, ball->size);
	}
	else {
		gameState++;
		ofFile file("HighScores.txt", ofFile::ReadWrite);
		file.open("HighScores.txt");
		file << ofToString(ball->score);
		file.close();
	}

	playerPaddle->draw();
	compPaddle->draw();
	ball->draw();
	projectile->draw();
	ofSetColor(0, 255, 0);

}


void ofApp::drawGameOverScreen() {
	GameOver.draw(175, 150, 1000, 200);
	HighScore.draw(200, 500, 300, 100);
	PlayAgain.draw(900, 500, 300, 100);
	highScoreFont.drawString(ofToString(ball->score), 250, 700);
}


void ofApp::updateGameScreen() {
	playerPaddle->move();
	playerPaddle->slow();
	compPaddle->AIMove();
	ball->move();
	projectile->projectileMotion();

	if ((projectile->x + projectile->size) >= (compPaddle->x)) {
		if ((projectile->y) <= (compPaddle->y + compPaddle->height)) {
			if ((projectile->y) >= (compPaddle->y)) {
				projectile->x = -100;
				projectile->y = -100;
			}
		}
	}

	if (projectile->x >= ofGetWindowWidth()) {
		projectile->x = -100;
		projectile->y = -100;
	}

	if ((ball->x - ball->size) <= (playerPaddle->x + playerPaddle->width)) {
		if ((ball->y) <= (playerPaddle->y + playerPaddle->height)) {
			if ((ball->y) >= (playerPaddle->y)) {
				ball->xVelocitySwitch();
				++ball->score;
				paddleSound.play();
			}
		}
	}

	if ((ball->x + ball->size) >= (compPaddle->x)) {
		if ((ball->y) <= (compPaddle->y + compPaddle->height)) {
			if ((ball->y) >= (compPaddle->y)) {
				ball->xVelocitySwitch();
				paddleSound.play();
			}
		}
	}

	if (ball->y > (compPaddle->y + (compPaddle->height / 2))) {
		++compPaddle->y;
	}
	if (ball->y < (compPaddle->y + (compPaddle->height / 2))) {
		--compPaddle->y;
	}

	if (ofGetMouseY() < playerPaddle->y) {
		playerPaddle->y -= 1;
	}

	if (ofGetMouseY() > playerPaddle->y) {
		playerPaddle->y += 1;
	}

	if ((projectile->score) == 0) {
		if (0 == (ball->score % 10) && 0 != (ball->score)) {
			++projectile->score;
		}
	}
}


void ofApp::keyPressed(int key) {
	if (key == OF_KEY_SHIFT) {
		if (projectile->score > 0) {
			projectile->x = playerPaddle->x + playerPaddle->width;
			projectile->y = playerPaddle->y + playerPaddle->height / 2;
			--projectile->score;
		}
	}

	if (key == OF_KEY_RETURN) {
		gameState = (gameState + 1) % 3;
	}
}


void ofApp::keyReleased(int key) {

}


void ofApp::mouseMoved(int x, int y ) {
	
}


void ofApp::mouseDragged(int x, int y, int button) {

}


void ofApp::mousePressed(int x, int y, int button) {
	if (gameState == 2) {
		gameState = (gameState + 1) % 3;
		ball->lives = 3;
		ball->x = (ofGetWindowWidth() / 2);
		ball->y = (ofGetWindowHeight() / 2);
		ball->xVelocity = ofRandom(-2, -0.5);
		ball->yVelocity = ofRandom(-0.5, 0.5);
		ball->score = 0;
	}
}


void ofApp::mouseReleased(int x, int y, int button) {

}


void ofApp::mouseEntered(int x, int y) {

}


void ofApp::mouseExited(int x, int y) {

}


void ofApp::windowResized(int w, int h) {

}


void ofApp::gotMessage(ofMessage msg) {

}


void ofApp::dragEvent(ofDragInfo dragInfo) { 

}

#pragma once
#include "ofMain.h"

class Ball {

public:
	float x;
	float y;
	float xVelocity;
	float yVelocity;
	int size;
	ofColor color;
	int score;
	int lives;
	Ball();
	Ball(float x, float y, float xVelocity, float yVelocity, int size, ofColor color, int score, int lives);
	void draw();
	void move();
	void xVelocitySwitch();
	void projectileMotion();
	void loadProjectile();
};
#include "ofApp.h"
#include "Ship.h"
#include "backgroundSauce.h"

void ofApp::setup() {
	ofSetBackgroundColor(0, 0, 0);
	ship = ship_struct((ofGetWindowWidth()/2), 0, 0, (ofGetWindowHeight() - 100), 0, 100, 100, 0, 0, 255);
	shipTwo = ship_struct((ofGetWindowWidth() / 2) - 100, 0, 0, (ofGetWindowHeight() - 100), 0, 100, 100, 0, 0, 255);
	spaceShip.load("ship.png");
}

void ofApp::update() {
	move_ship(ship);
	move_ship(shipTwo);
}

void ofApp::draw() {
	draw_fps_and_score();
	ship_draw(ship, spaceShip);
	ship_draw(shipTwo, spaceShip);
	
}

void ofApp::keyPressed(int key) {
	if (key == OF_KEY_RIGHT) {
		ship_move_right(ship);
		ship_move_right(shipTwo);
	}
	if (key == OF_KEY_LEFT) {
		ship_move_left(ship);
		ship_move_left(shipTwo);
	}

	if (key == OF_KEY_UP) {
		ship_move_up(ship);
		ship_move_up(shipTwo);
	}
	if (key == OF_KEY_DOWN) {
		ship_move_down(ship);
		ship_move_down(shipTwo);
	}
	
}

void ofApp::keyReleased(int key) {

}

void ofApp::mouseMoved(int x, int y ) {

}

void ofApp::mouseDragged(int x, int y, int button) {

}

void ofApp::mousePressed(int x, int y, int button) {

}

void ofApp::mouseReleased(int x, int y, int button) {

}

void ofApp::mouseEntered(int x, int y) {

}

void ofApp::mouseExited(int x, int y) {

}

void ofApp::windowResized(int w, int h) {

}

void ofApp::gotMessage(ofMessage msg) {

}

void ofApp::dragEvent(ofDragInfo dragInfo) { 

}
#pragma once

void draw_fps_and_score();
#include "ofMain.h"

void draw_fps_and_score() {
	//draw FPS and Frame count, and color both
	ofSetColor(255, 255, 255);
	std::string str_fps = "FPS: ";
	str_fps += ofToString(ofGetFrameRate());
	ofSetColor(255, 255, 255);
	std::string str_frameNum = "Frame #: ";
	str_frameNum += ofToString(ofGetFrameNum());
	
	//Draw score with color
	ofSetColor(255, 255, 255);
	ofDrawBitmapString("score:", (ofGetWidth() / 2) - 50, 30);
	ofDrawBitmapString(str_fps, 10, 20);
	ofDrawBitmapString(str_frameNum, 10, 10);
}
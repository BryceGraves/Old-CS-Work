#include "Block.h"
#include "ofMain.h"

const char A = 'A';
const char B = 'B';
const char C = 'C';
const char D = 'D';
const char E = 'E';
const char F = 'F';

Block::Block() {

}

Block::Block(double x, double y, double width, double height, int score, ofColor color, char type, int broken) {
	this->x = x;
	this->y = y;
	this->width = width;
	this->height = height;
	this->score = score;
	this->color = color;
	this->broken = broken;
	if (type == A) {
		this->color = ofColor(255, 0, 0);
		this->score = 10;
	}
	else if (type == B) {
		this->color = ofColor(0, 255, 0);
		this->score = 20;
	}
	else if (type == C) {
		this->color = ofColor(0, 0, 255);
		this->score = 40;
	}
	else if (type == D) {
		this->color = ofColor(148, 175, 70);
		this->score = 60;
	}
	else if (type == E) {
		this->color = ofColor(42, 19, 241);
		this->score = 80;
	}
	else if (type == F) {
		this->color = ofColor(42, 139, 4);
		this->score = 100;
	}
}

void Block::draw() {
	ofSetColor(color, broken);
	ofDrawRectangle(x, y, width, height);
	ofSetBoxResolution(60);
}

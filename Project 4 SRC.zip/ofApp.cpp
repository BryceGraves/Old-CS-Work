#include "ofApp.h"

using namespace std;

const int START_SCREEN = 0;
const int GAME_SCREEN = 1;
const int GAME_OVER_SCREEN = 2;
const int levelOne = 1;
const int levelTwo = 2;
const int levelThree = 3;
const int levelFour = 4;

vector<Block*> blocks;

int gameState = START_SCREEN;
int levelState = levelOne;
int blocksLeft = blocks.size();

void ofApp::setup() {

	//Set background color and framerate
	ofSetBackgroundColor(0);
	ofSetFrameRate(60);

	//Load fonts, titles, and sounds
	myFont.load("Font.ttf", 10);
	titleFont.load("Font.ttf", 50);
	Title.load("Title.png");
	paddleSound.load("paddleSound.wav");

	//constructs paddle and ball; Also sets their starting velocity
	playerPaddle = new Paddle(((ofGetWidth() / 2) - 30), ofGetHeight() - 60, 0, 60, 20, ofColor(0, 255, 0));
	ball = new Ball(10, ofColor(0, 255, 0), 0, 3);
	ball->velocity.set(ofRandom(-2, 2), -2);
	ball->location.set((ofGetWidth() / 2), (ofGetHeight() / 2) + 200);
}


void ofApp::update() {
	//Check to see if gamestate is on update screen. TODO: Make update screen for the three other levels
	if (gameState == GAME_SCREEN) {
		updateGameScreen();
	}
}


void ofApp::draw() {
	//Checks gamestate and draws the correct screen
	if (gameState == START_SCREEN) {
		drawStartScreen();
	}
	else if (gameState == GAME_SCREEN) {
		drawGameScreen();
	}
	else if (gameState == GAME_OVER_SCREEN) {
		drawGameOverScreen();
	}
}


void ofApp::drawStartScreen() {
	//Set the color to white; draw the title and the strings for level names
	ofSetColor(255, 255, 255);
	titleFont.drawString("1. Easy", 50, (ofGetWindowHeight() / 2) + 20);
	titleFont.drawString("2. Kind of Hard", 50, (ofGetWindowHeight() / 2) + 100);
	titleFont.drawString("3. Hard", 50, (ofGetWindowHeight() / 2) + 180);
	titleFont.drawString("4. Please Don't Do It", 50, (ofGetWindowHeight() / 2) + 260);
	Title.draw(0, 150, ofGetWindowWidth(), 200);

}


void ofApp::drawGameScreen() {
	//Draw FPS and Framenumber labels
	ofSetColor(255, 255, 255);
	std::string str_fps = "FPS: ";
	str_fps += ofToString(ofGetFrameRate());
	std::string str_frameNum = "Frame #: ";
	str_frameNum += ofToString(ofGetFrameNum());
	std::string str_score = "Score: ";
	str_score += ofToString(ball->score);


	//Draw framerate, framenumber, and score; with color
	ofSetColor(255, 255, 255);
	myFont.drawString(str_fps, 10, 40);
	myFont.drawString(str_frameNum, 10, 20);
	myFont.drawString(str_score, (ofGetWidth() / 2) - 50, 20);

	//Draws circles to represent lives in the top right corner
	ofSetColor(0, 255, 0);
	if (ball->lives == 3) {
		ofDrawCircle((ofGetWindowWidth() - ((ball->size * 1) + 1)), ball->size, ball->size);
		ofDrawCircle((ofGetWindowWidth() - ((ball->size * 3) + 1)), ball->size, ball->size);
		ofDrawCircle((ofGetWindowWidth() - ((ball->size * 5) + 1)), ball->size, ball->size);
	}
	else if (ball->lives == 2) {
		ofDrawCircle((ofGetWindowWidth() - ((ball->size * 1) + 1)), ball->size, ball->size);
		ofDrawCircle((ofGetWindowWidth() - ((ball->size * 3) + 1)), ball->size, ball->size);
	}
	else if (ball->lives == 1) {
		ofDrawCircle((ofGetWindowWidth() - ((ball->size * 1) + 1)), ball->size, ball->size);
	}
	else {
		gameState++;
	}

	//Draw each block in the block vector
	for (int i = 0; i < blocks.size(); ++i) {
		blocks[i]->draw();
	}

	//Draws the paddle and ball
	playerPaddle->draw();
	ball->draw();
	ofSetColor(0, 255, 0);

}


void ofApp::drawGameOverScreen() {
	std::string str_score = "Score: ";
	str_score += ofToString(ball->score);
	titleFont.drawString(str_score, (ofGetWidth() / 2) - 200, 200);

	std::string str_playAgain = "Press Backspace to Play Again";
	titleFont.drawString(str_playAgain, (ofGetWidth() / 2) - 800, 400);
}


void ofApp::updateGameScreen() {
	//Moves the paddle and ball
	playerPaddle->move();
	ball->move();



	//Ball bounces on paddle, checks the x bounds and the y bounds before bounce
	if ((ball->location.y + ball->size) >= (playerPaddle->y)) {
		if ((ball->location.x - ball->size) <= (playerPaddle->x + (playerPaddle->width))) {
			if ((ball->location.x + ball->size) >= (playerPaddle->x)) {
				//Angled ball bounce, maps the width of the paddle to a -2 to 2 x velocity
				float Bounce = ofMap(ball->location.x, playerPaddle->x, playerPaddle->x + (playerPaddle->width), -2, 2);
				ball->velocity.x = Bounce;
				ball->velocity.y *= -1;
				++ball->score;
				paddleSound.play();
			}
		}
	}

	for (int i = 0; i < blocks.size(); ++i) {
		if ((ball->location.y - ball->size) <= (blocks[i]->y + blocks[i]->height)) {
			if ((ball->location.y) >= (blocks[i]->y + (blocks[i]->height / 2))) {
				if ((ball->location.x) <= ((blocks[i]->x + (blocks[i]->width)) + 1)) {
					if ((ball->location.x) >= (blocks[i]->x) - 1) {
						if (blocks[i]->broken > 0) {
							ball->velocity.y *= -1;
							ball->location.y = ((blocks[i]->y + blocks[i]->height) + ball->size);
							ball->score += blocks[i]->score;
							free(blocks[i]);
							paddleSound.play();
							++blocksLeft;
							return;
						}
					}
				}
			}
		}
	}

	for (int i = 0; i < blocks.size(); ++i) {
		if ((ball->location.y + ball->size) >= (blocks[i]->y)) {
			if ((ball->location.y) <= (blocks[i]->y + (blocks[i]->height / 2))) {
				if ((ball->location.x) <= ((blocks[i]->x + (blocks[i]->width)) + 1)) {
					if ((ball->location.x) >= (blocks[i]->x) - 1) {
						if (blocks[i]->broken > 0) {
							ball->velocity.y *= -1;
							ball->location.y = (blocks[i]->y - ball->size);
							ball->score += blocks[i]->score;
							free(blocks[i]);
							paddleSound.play();
							++blocksLeft;
							return;
						}
					}
				}
			}
		}
	}

	for (int i = 0; i < blocks.size(); ++i) {
		if ((ball->location.x - ball->size) <= (blocks[i]->x + blocks[i]->width)) {
			if ((ball->location.x) >= (blocks[i]->x + (blocks[i]->width / 2))) {
				if ((ball->location.y) <= ((blocks[i]->y + (blocks[i]->height)) + 1)) {
					if ((ball->location.y) >= (blocks[i]->y) - 1) {
						if (blocks[i]->broken > 0) {
							ball->velocity.x *= -1;
							ball->location.x = ((blocks[i]->x + blocks[i]->height) + ball->size);
							ball->score += blocks[i]->score;
							free(blocks[i]);
							paddleSound.play();
							++blocksLeft;
							return;
						}
					}
				}
			}
		}
	}

	for (int i = 0; i < blocks.size(); ++i) {
		if ((ball->location.x + ball->size) >= (blocks[i]->x)) {
			if ((ball->location.x) <= (blocks[i]->x + (blocks[i]->width / 2))) {
				if ((ball->location.y) <= ((blocks[i]->y + (blocks[i]->height)) + 1)) {
					if ((ball->location.y) >= (blocks[i]->y) - 1) {
						if (blocks[i]->broken > 0) {
							ball->velocity.x *= -1;
							ball->location.x = (blocks[i]->x - ball->size);
							ball->score += blocks[i]->score;
							free(blocks[i]);
							paddleSound.play();
							++blocksLeft;
							return;
						}
					}
				}
			}
		}
	}

	if (blocks.size() == blocksLeft) {
		++levelState;
		levelLoad(levelState);
		ball->location.set((ofGetWidth() / 2), (ofGetHeight() / 2) + 200);
		ball->velocity.set(ofRandom(-2, 2), -2);
	}

}

void ofApp::levelLoad(int level) {
	blocks.clear();

	//Read from file and push into vector lines
	ofBuffer buffer = ofBufferFromFile(ofToString(level) += ".txt");
	vector<string> lines;
	for (auto line : buffer.getLines()) {
		lines.push_back(line);
	}

	//Takes vector lines and fills it with strings called row
	for (int i = 0; i < lines.size(); ++i) {
		string row = lines[i];
		cout << "ROW " << i + 1 << endl;

		//Takes each string and prints each char per string
		for (int j = 0; j < row.size(); ++j) {
			cout << "Block: " << row[j] << endl;

			double blockWidth = (ofGetWidth() / row.size());
			double blockHeight = ((ofGetHeight() / 2) / lines.size());

			char letters = row[j];
			if (letters != ' ') {
				blocks.push_back(new Block(blockWidth * j, 50 + (blockHeight * i), blockWidth, blockHeight, 1, ofColor(0, 255, 255), letters, 255));
			}
		}
	}
}

void ofApp::levelSelect(int key) {
	if (gameState == START_SCREEN) {
		levelState = (key - 48);

		//Read from file and push into vector lines
		vector<string> lines;
		ofBuffer buffer = ofBufferFromFile(ofToString(levelState) + ".txt");
		for (auto line : buffer.getLines()) {
			lines.push_back(line);
		}

		//Takes vector lines and fills it with strings called row
		for (int i = 0; i < lines.size(); ++i) {
			string row = lines[i];
			cout << "ROW " << i + 1 << endl;

			//Takes each string and prints each char per string
			for (int j = 0; j < row.size(); ++j) {
				cout << "Block: " << row[j] << endl;

				double blockWidth = (ofGetWidth() / row.size());
				double blockHeight = ((ofGetHeight() / 2) / lines.size());

				char letters = row[j];
				if (letters != ' ') {
					blocks.push_back(new Block(blockWidth * j, 50 + (blockHeight * i), blockWidth, blockHeight, 1, ofColor(0, 255, 255), letters, 255));
				}
			}
		}
		++gameState;
	}
}


void ofApp::keyPressed(int key) {
	
	if (key == 49) {
		levelSelect(key);
	}
	else if (key == 50) {
		levelSelect(key);
	}
	else if (key == 51) {
		levelSelect(key);
	}
	else if (key == 52) {
		levelSelect(key);
	}

	if (key == OF_KEY_BACKSPACE) {
		if (gameState == GAME_OVER_SCREEN) {
			blocks.clear();
			ball->lives = 3;
			ball->score = 0;
			gameState = (gameState + 1) % 3;
		}
	}
}


void ofApp::keyReleased(int key) {

}


void ofApp::mouseMoved(int x, int y) {

}


void ofApp::mouseDragged(int x, int y, int button) {

}


void ofApp::mousePressed(int x, int y, int button) {

}


void ofApp::mouseReleased(int x, int y, int button) {

}


void ofApp::mouseEntered(int x, int y) {

}


void ofApp::mouseExited(int x, int y) {

}


void ofApp::windowResized(int w, int h) {

}


void ofApp::gotMessage(ofMessage msg) {

}


void ofApp::dragEvent(ofDragInfo dragInfo) {

}
#pragma once

#include "ofMain.h"

class Block {

public:
	double x;
	double y;
	double width;
	double height;
	int score;
	ofColor color;
	int broken;
	Block();
	Block(double x, double y, double width, double height, int score, ofColor color, char type, int broken);
	void draw();

};
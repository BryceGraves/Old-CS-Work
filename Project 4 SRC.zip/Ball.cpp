#include "ofMain.h"
#include "Ball.h"

const int DEFAULT_VELOCITY = 1;

Ball::Ball() {

}

Ball::Ball(int size, ofColor color, int score, int lives) {
	this->size = size;
	this->color = color;
	this->score = score;
	this->lives = lives;
}

void Ball::draw() {
	ofSetColor(color);
	ofNoFill();
	ofDrawCircle(location.x, location.y, size);
	ofSetCircleResolution(60);
}

void Ball::move() {
	//Moves the ball via velocity
	location += velocity;

	//Ball bounce logic, for the bottom/top and the sides
	if (location.y <= size) {
		location.y = size;
		velocity.y *= -1;
	}
	else if (location.y >= ofGetWindowHeight() - size) {
		location.y = ofGetWindowHeight() - size;
		velocity.y *= -1;
		--lives;
	}

	if (location.x <= size) {
		location.x = size;
		velocity.x *= -1;
	}
	else if (location.x >= ofGetWindowWidth() - size) {
		location.x = ofGetWindowWidth() - size;
		velocity.x *= -1;
	}
}
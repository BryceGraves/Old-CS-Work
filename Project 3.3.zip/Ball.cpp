#include "Ball.h"
#include "Paddle.h"
#include "ofMain.h"


Ball::Ball() {
	x = ofGetWindowWidth();
	y = ofGetWindowHeight();
	size = size;
	color = ofColor();
}

Ball::Ball(float x, float y, float xVelocity, float yVelocity, int size, ofColor color) {
	this->x = x;
	this->y = y;
	this->xVelocity = xVelocity;
	this->yVelocity = yVelocity;
	this->size = size;
	this->color = color;
}

void Ball::draw() {
	ofSetColor(color);
	ofDrawCircle(x, y, size);
	ofSetCircleResolution(60);
}

void Ball::move() {
	y += yVelocity;
	x += xVelocity;

	if (x <= size) {
		x = size;
		xVelocity *= -1;
	} else if (x >= ofGetWindowWidth() - size) {
		x = ofGetWindowWidth() - size;
		xVelocity *= -1;
	}

	if (y <= size) {
		y = size;
		yVelocity *= -1;
	} else if (y >= ofGetWindowHeight() - size) {
		y = ofGetWindowHeight() - size;
		yVelocity *= -1;
	}

}

void Ball::xVelocitySwitch() {
	xVelocity *= -1;
}


#include "Paddle.h"
#include "ofMain.h"


Paddle::Paddle() {
	x = ofGetWindowWidth();
	y = ofGetWindowHeight();
	width = 5;
	height = 5;
	color = ofColor();
}

Paddle::Paddle(float x, float y, float v, int width, int height, ofColor color) {
	this->x = x;
	this->y = y;
	this->v = v;
	this->width = width;
	this->height = height;
	this->color = color;
}

void Paddle::draw() {
	ofSetColor(color);
	ofDrawRectangle(x, y, width, height);
	ofSetBoxResolution(60);
}

void Paddle::moveUp() {
	v -= 1;
}

void Paddle::moveDown() {
	v += 1;
}

void Paddle::move() {
	y += v;

	if (y <= 0) {
		y = 0;
	}
	else if (y >= ofGetWindowHeight() - height) {
		y = ofGetWindowHeight() - height;
	}
}

void Paddle::slow() {
	v *= 0.95;
}


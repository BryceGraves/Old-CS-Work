#include "ofApp.h"
#include "Paddle.h"
#include "Ball.h"



void ofApp::setup() {
	ofSetBackgroundColor(0);
	phil = new Paddle(60, (ofGetHeight() / 2), 0, 20, 60, ofColor(0, 255, 0));
	stan = new Paddle((ofGetWidth() - 80), (ofGetHeight() / 2), 0, 20, 60, ofColor(0, 255, 0));
	bob = new Ball((ofGetWidth() / 2), (ofGetHeight() / 2), ofRandom(-2, 1), ofRandom(-0.5, 0.5), 10, ofColor(0, 255, 0));
}


void ofApp::update() {
	phil->move();
	phil->slow();
	bob->move();

	if ((bob->x - bob->size) <= (phil->x + phil->width)) {
		if ((bob->y) < (phil->y + phil->height)) {
			if ((bob->y) > (phil->y)) {
				bob->xVelocitySwitch();
			}
		}
	}

	if ((bob->x + bob->size) >= (stan->x)) {
		if ((bob->y) < (stan->y + stan->height)) {
			if ((bob->y) > (stan->y)) {
				bob->xVelocitySwitch();
			}
		}
	}

	if (bob->y > (stan->y)) {
		++stan->y;
	}
	if (bob->y < (stan->y + (stan->height / 2))) {
		--stan->y;
	}
}


void ofApp::draw() {
	phil->draw();
	stan->draw();
	bob->draw();
}


void ofApp::keyPressed(int key) {
	if (key == OF_KEY_UP) {
		phil->moveUp();
	}
	
	if (key == OF_KEY_DOWN) {
		phil->moveDown();
	}
}


void ofApp::keyReleased(int key) {

}


void ofApp::mouseMoved(int x, int y ) {

}


void ofApp::mouseDragged(int x, int y, int button) {

}


void ofApp::mousePressed(int x, int y, int button) {

}


void ofApp::mouseReleased(int x, int y, int button) {

}


void ofApp::mouseEntered(int x, int y) {

}


void ofApp::mouseExited(int x, int y) {

}


void ofApp::windowResized(int w, int h) {

}


void ofApp::gotMessage(ofMessage msg) {

}


void ofApp::dragEvent(ofDragInfo dragInfo) { 

}
